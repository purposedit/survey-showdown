import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import Papa from "papaparse";
import { v4 as uuidv4 } from "uuid";
import confetti from "canvas-confetti";
import Fuse from "fuse.js";

// IMPORTANT: Do NOT statically import firebase/firestore or firebase/auth here.
// In the canvas/sandbox environment, Firestore may be unavailable, which can throw
// "Service firestore is not available" at module-evaluation time. We lazy-load
// the SDK modules only when the user supplies a Firebase config and the browser
// environment supports them.
import { initializeApp, type FirebaseApp } from "firebase/app";

// shadcn/ui kit imports
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Copy,
  Eye,
  EyeOff,
  TimerReset,
  Upload,
  Users,
  Play,
  Pause,
  Plus,
  Minus,
  MonitorSmartphone,
  Projector,
  Hand,
  Trophy,
  Swords,
  Settings as Cog,
  Link as LinkIcon,
} from "lucide-react";

// -------------------------
// Types
// -------------------------

type QA = { text: string; points: number; revealed?: boolean };

type Question = {
  id: string;
  category?: string;
  prompt: string;
  notes?: string;
  answers: QA[]; // sorted by points desc typically
};

type Team = { id: string; name: string; score: number };

type TimerState = { duration: number; remaining: number; running: boolean };

type Phase = "faceoff" | "board" | "steal" | "fastmoney";

type FastMoneySlot = { prompt: string; answer1?: string; answer2?: string; points?: number };

type FastMoneyState = {
  active: boolean;
  timer: TimerState;
  slots: FastMoneySlot[]; // 5 prompts
  teamId?: string; // which team is playing FM
  playerIndex: 1 | 2; // player 1 then 2
  score1: number;
  score2: number;
};

type GameState = {
  id: string;
  mode: "local" | "cloud";
  teams: Team[];
  boardTheme: "dark" | "light";
  currentQuestionId?: string;
  strikeCount: number; // 0-3
  turnTeamId?: string;
  timer: TimerState;
  showAnswers: boolean; // reveal all switch
  questions: Record<string, Question>;
  hostNotes?: string;
  lastUpdated: number;
  // Roadmap features
  roundMultiplier: 1 | 2 | 3;
  pot: number; // sum of revealed points * multiplier in current round
  phase: Phase;
  buzzerLocked: boolean;
  buzzerWinnerTeamId?: string; // faceoff lockout winner
  soundEnabled: boolean;
  fastMoney: FastMoneyState;
};

// -------------------------
// Helpers
// -------------------------

const DEFAULT_TIMER = 30;

function blankGame(id: string): GameState {
  return {
    id,
    mode: "local",
    teams: [
      { id: uuidv4(), name: "Team A", score: 0 },
      { id: uuidv4(), name: "Team B", score: 0 },
    ],
    boardTheme: "dark",
    currentQuestionId: undefined,
    strikeCount: 0,
    turnTeamId: undefined,
    timer: { duration: DEFAULT_TIMER, remaining: DEFAULT_TIMER, running: false },
    showAnswers: false,
    questions: {},
    hostNotes: "",
    lastUpdated: Date.now(),
    roundMultiplier: 1,
    pot: 0,
    phase: "faceoff",
    buzzerLocked: false,
    buzzerWinnerTeamId: undefined,
    soundEnabled: true,
    fastMoney: {
      active: false,
      timer: { duration: 60, remaining: 60, running: false },
      slots: Array.from({ length: 5 }).map(() => ({ prompt: "" })),
      teamId: undefined,
      playerIndex: 1,
      score1: 0,
      score2: 0,
    },
  };
}

function formatPoints(n: number) {
  return `${n}`;
}

function parseCSVToQuestions(csvText: string): Question[] {
  // Expected columns: category,question,answer1,score1,answer2,score2,... answer10,score10,notes
  const rows = Papa.parse<string[]>(csvText, { header: false }).data as string[][];
  const out: Question[] = [];
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (!r || r.length === 0) continue;
    const [category, prompt, ...rest] = r;
    if (!prompt) continue;
    const answers: QA[] = [];
    for (let j = 0; j < 20; j += 2) {
      const a = rest[j];
      const s = rest[j + 1];
      if (a === undefined && s === undefined) continue;
      const text = (a || "").trim();
      const points = Number(s || 0) || 0;
      if (text.length) answers.push({ text, points, revealed: false });
    }
    const notes = rest[20] || "";
    out.push({ id: uuidv4(), category, prompt, notes, answers });
  }
  return out;
}

function questionsToCSVTemplate(): string {
  const headers = [
    "category",
    "question",
    ...Array.from({ length: 10 }).flatMap((_, i) => [`answer${i + 1}`, `score${i + 1}`]),
    "notes",
  ];
  const example = [
    "Food",
    "Name a popular pizza topping",
    "Pepperoni",
    "30",
    "Mushrooms",
    "20",
    "Extra cheese",
    "15",
    "Sausage",
    "12",
    "Onions",
    "10",
    "Olives",
    "6",
    "Bacon",
    "5",
    "Pineapple",
    "2",
    "Ham",
    "0",
    "Say the top 10 if you have them; fewer is fine.",
  ];
  const csv = Papa.unparse({ fields: headers, data: [example] });
  return csv;
}

function downloadText(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// useInterval MUST return ONLY a cleanup function – not JSX
function useInterval(callback: () => void, delay: number | null) {
  const savedRef = useRef(callback);
  useEffect(() => {
    savedRef.current = callback;
  }, [callback]);
  useEffect(() => {
    if (delay === null) return;
    const id = setInterval(() => savedRef.current(), delay);
    return () => clearInterval(id);
  }, [delay]);
}

// Basic sounds via tiny base64 clips (guarded for SSR)
let SOUND_DING: HTMLAudioElement | null = null;
let SOUND_BUZZ: HTMLAudioElement | null = null;
if (typeof window !== "undefined" && typeof Audio !== "undefined") {
  try { SOUND_DING = new Audio("data:audio/mp3;base64,//uQZAAAA"); } catch {}
  try { SOUND_BUZZ = new Audio("data:audio/mp3;base64,//uQZAAAA"); } catch {}
}
function play(audio: HTMLAudioElement | null) { try { if (audio) { audio.currentTime = 0; audio.play(); } } catch {} }

// Lightweight toast shim (no external provider required)
function useToast() {
  return {
    toast({ title, description }: { title: string; description?: string }) {
      try { console.log("[toast]", title, description || ""); } catch {}
      try { if (typeof window !== "undefined") alert(`${title}${description ? " — " + description : ""}`); } catch {}
    },
  } as const;
}

// Fuzzy matching helper
function buildFuse(answers: QA[]) {
  return new Fuse(answers, { keys: ["text"], includeScore: true, threshold: 0.4 });
}
function normalize(s: string) {
  const lowered = s.toLowerCase();
  const lettersDigitsSpace = lowered
    .split("")
    .map((ch) => (/[a-z0-9 ]/.test(ch) ? ch : ""))
    .join("");
  return lettersDigitsSpace.replace(/ +/g, " ").trim();
}

// Build role URLs from a base and gameId (pure; testable)
function buildRoleUrls(base: string, gameId: string) {
  // Strip trailing "/index.html" (common in previews) and any trailing slash for a clean base
  const cleanBase = base.replace(/(?:\/index\.html)?\/?$/i, "");
  return {
    admin: `${cleanBase}?role=admin&game=${gameId}`,
    host: `${cleanBase}?role=host&game=${gameId}`,
    board: `${cleanBase}?role=board&game=${gameId}`,
  } as const;
}

// -------------------------
// Clipboard-safe utility (sandbox-friendly)
// -------------------------
export async function safeCopy(text: string): Promise<boolean> {
  // Try async Clipboard API first
  try {
    if (typeof navigator !== "undefined" && (navigator as any).clipboard?.writeText) {
      await (navigator as any).clipboard.writeText(text);
      return true;
    }
  } catch {
    // fall through to execCommand
  }
  // Fallback to a hidden textarea + execCommand
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return !!ok;
  } catch {
    return false;
  }
}

// -------------------------
// Public Base URL helper (lets links work after deploy)
// -------------------------
function getPublicBase(): string {
  try {
    return (typeof window !== "undefined" ? localStorage.getItem("surveyshowdown_public_base") : "") || "";
  } catch {
    return "";
  }
}
function setPublicBase(url: string) {
  try {
    if (typeof window !== "undefined") {
      if (url) localStorage.setItem("surveyshowdown_public_base", url);
      else localStorage.removeItem("surveyshowdown_public_base");
    }
  } catch {}
}

// -------------------------
// Firebase glue (optional, lazy, sandbox-safe)
// -------------------------

type FirebaseConfig = {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId?: string;
};

type FirestoreModule = {
  getFirestore: (app?: FirebaseApp) => any;
  doc: (...args: any[]) => any;
  setDoc: (...args: any[]) => Promise<any>;
  updateDoc: (...args: any[]) => Promise<any>;
  getDoc: (...args: any[]) => Promise<any>;
  onSnapshot: (...args: any[]) => () => void;
};

function useCloudSync(game: GameState | null, setGame: (g: GameState) => void) {
  const [fbCfg, setFbCfg] = useState<FirebaseConfig | null>(null);
  const [connected, setConnected] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // Keep refs to Firestore module + db so we can call without re-importing each time
  const fsRef = useRef<FirestoreModule | null>(null);
  const dbRef = useRef<any>(null);
  const appRef = useRef<FirebaseApp | null>(null);

  useEffect(() => {
    try {
      const cached = typeof window !== "undefined" ? localStorage.getItem("surveyshowdown_firebase") : null;
      if (cached) setFbCfg(JSON.parse(cached));
    } catch {}
  }, []);

  // Attempt to connect when config changes (lazy import in browser only)
  useEffect(() => {
    let unsub: (() => void) | null = null;
    (async () => {
      if (!fbCfg || typeof window === "undefined") return; // local mode
      try {
        // Initialize (idempotent name per project)
        const app = initializeApp(fbCfg, `surveyshowdown-${fbCfg.projectId}`);
        appRef.current = app;

        // Lazy auth (optional)
        try {
          const authMod: any = await import(/*$1*/ "firebase/auth");
          if (authMod?.getAuth) {
            const auth = authMod.getAuth(app);
            if (authMod?.signInAnonymously) authMod.signInAnonymously(auth).catch(() => {});
          }
        } catch (e) {
          // Auth not available in sandbox; ignore
        }

        // Lazy Firestore (critical) — may fail in sandbox; handle gracefully
        try {
          const fs: any = await import(/* @vite-ignore */ "firebase/firestore");
          fsRef.current = fs as FirestoreModule;
          const db = fs.getFirestore(app);
          dbRef.current = db;
          setConnected(true);
          setErr(null);

          // Start listener for current game
          if (game) {
            const ref = fs.doc(db, "games", game.id);
            unsub = fs.onSnapshot(ref, (snap: any) => {
              try {
                if (!snap?.exists?.()) return;
                const data = snap.data() as GameState;
                if (!data || !data.lastUpdated) return;
                if (!game.lastUpdated || data.lastUpdated > game.lastUpdated) setGame({ ...data });
              } catch {}
            });
          }
        } catch (e: any) {
          // The sandbox may not have Firestore service available
          setConnected(false);
          setErr("firestore_unavailable");
          fsRef.current = null;
          dbRef.current = null;
        }
      } catch (e: any) {
        setConnected(false);
        setErr(e?.message || "init_failed");
      }
    })();

    return () => { try { if (unsub) unsub(); } catch {} };
  }, [fbCfg, game?.id]);

  async function push(g: GameState) {
    try {
      const fs = fsRef.current;
      const db = dbRef.current;
      if (!fs || !db) return; // no-op in local mode or if Firestore missing
      const ref = fs.doc(db, "games", g.id);
      const snap = await fs.getDoc(ref);
      if (snap?.exists?.()) await fs.updateDoc(ref, { ...g }); else await fs.setDoc(ref, { ...g });
    } catch {
      // swallow to keep the UI responsive in local/sandbox mode
    }
  }

  return {
    connected,
    error: err,
    setFirebaseConfig: (cfg: FirebaseConfig | null) => {
      try {
        if (cfg) localStorage.setItem("surveyshowdown_firebase", JSON.stringify(cfg));
        else localStorage.removeItem("surveyshowdown_firebase");
      } catch {}
      setFbCfg(cfg);
    },
    push,
  } as const;
}

// -------------------------
// UI Components
// -------------------------

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card className="mb-4">
      <CardHeader>
        <CardTitle className="text-xl">{title}</CardTitle>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

function TeamEditor({ game, setGame, push }: { game: GameState; setGame: (g: GameState) => void; push?: (g: GameState) => void }) {
  const update = (partial: Partial<GameState>) => {
    const g = { ...game, ...partial, lastUpdated: Date.now() };
    setGame(g);
    push?.(g);
  };
  function addTeam() {
    update({ teams: [...game.teams, { id: uuidv4(), name: `Team ${String.fromCharCode(65 + game.teams.length)}`, score: 0 }] });
  }
  function removeTeam(id: string) {
    update({ teams: game.teams.filter((t) => t.id !== id) });
  }
  function setScore(id: string, delta: number) {
    update({ teams: game.teams.map((t) => (t.id === id ? { ...t, score: Math.max(0, t.score + delta) } : t)) });
  }
  return (
    <Section title="Teams">
      <div className="grid md:grid-cols-2 gap-3">
        {game.teams.map((t) => (
          <Card key={t.id} className="p-3">
            <div className="flex items-center gap-2">
              <Input value={t.name} onChange={(e) => update({ teams: game.teams.map((x) => (x.id === t.id ? { ...x, name: e.target.value } : x)) })} />
              <div className="flex items-center gap-2">
                <Button variant="outline" onClick={() => setScore(t.id, -5)} size="icon">
                  <Minus size={16} />
                </Button>
                <div className="w-16 text-center font-bold text-lg">{t.score}</div>
                <Button onClick={() => setScore(t.id, +5)} size="icon">
                  <Plus size={16} />
                </Button>
              </div>
              <Button variant="destructive" onClick={() => removeTeam(t.id)}>
                Remove
              </Button>
            </div>
          </Card>
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        <Button onClick={addTeam}>
          <Users className="mr-2" size={16} /> Add Team
        </Button>
      </div>
    </Section>
  );
}

function QuestionsManager({ game, setGame, push }: { game: GameState; setGame: (g: GameState) => void; push?: (g: GameState) => void }) {
  const { toast } = useToast();
  const update = (partial: Partial<GameState>) => {
    const g = { ...game, ...partial, lastUpdated: Date.now() };
    setGame(g);
    push?.(g);
  };
  function handleUpload(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = String(reader.result);
        const qs = parseCSVToQuestions(text);
        const asMap: Record<string, Question> = {};
        qs.forEach((q) => (asMap[q.id] = q));
        update({ questions: { ...game.questions, ...asMap } });
        toast({ title: "Questions imported", description: `${qs.length} added.` });
      } catch (e: any) {
        toast({ title: "Import failed", description: e?.message || String(e) });
      }
    };
    reader.readAsText(file);
  }
  function downloadTemplate() {
    downloadText("survey_showdown_questions_template.csv", questionsToCSVTemplate());
  }
  function setCurrent(qid: string) {
    update({
      currentQuestionId: qid,
      showAnswers: false,
      strikeCount: 0,
      pot: 0,
      phase: "faceoff",
      timer: { ...game.timer, remaining: game.timer.duration, running: false },
      buzzerLocked: false,
      buzzerWinnerTeamId: undefined,
    });
  }
  const list = Object.values(game.questions);
  return (
    <Section title="Questions">
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <label className="cursor-pointer inline-flex items-center gap-2">
          <Input type="file" accept=".csv" onChange={(e) => e.target.files && handleUpload(e.target.files[0])} />
        </label>
        <Button variant="outline" onClick={downloadTemplate}>
          <Upload className="mr-2" size={16} /> Download CSV Template
        </Button>
      </div>
      {list.length === 0 ? (
        <Alert>
          <AlertTitle>No questions yet</AlertTitle>
          <AlertDescription>Upload a CSV using the template, or add them manually below.</AlertDescription>
        </Alert>
      ) : (
        <div className="grid md:grid-cols-2 gap-3">
          {list.map((q) => (
            <Card key={q.id} className={`p-3 ${game.currentQuestionId === q.id ? "ring-2 ring-primary" : ""}`}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="uppercase text-xs opacity-70">{q.category || "General"}</div>
                  <div className="font-semibold">{q.prompt}</div>
                  <div className="text-xs opacity-70">{q.answers.length} answers</div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => setCurrent(q.id)}>
                    Set Current
                  </Button>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Edit Question</DialogTitle>
                      </DialogHeader>
                      <QuestionEditor q={q} onSave={(qq) => update({ questions: { ...game.questions, [qq.id]: qq } })} />
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
      <div className="mt-3">
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="secondary">Add Question Manually</Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>New Question</DialogTitle>
            </DialogHeader>
            <QuestionEditor onSave={(qq) => update({ questions: { ...game.questions, [qq.id]: qq } })} />
          </DialogContent>
        </Dialog>
      </div>
    </Section>
  );
}

function QuestionEditor({ q, onSave }: { q?: Question; onSave: (q: Question) => void }) {
  const [local, setLocal] = useState<Question>(
    q || { id: uuidv4(), category: "", prompt: "", notes: "", answers: Array.from({ length: 8 }).map(() => ({ text: "", points: 0 })) }
  );
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3 items-center">
        <Label>Category</Label>
        <Input value={local.category || ""} onChange={(e) => setLocal({ ...local, category: e.target.value })} />
        <Label>Question</Label>
        <Input value={local.prompt} onChange={(e) => setLocal({ ...local, prompt: e.target.value })} />
        <Label>Notes (to host)</Label>
        <Textarea value={local.notes || ""} onChange={(e) => setLocal({ ...local, notes: e.target.value })} />
      </div>
      <div className="mt-2">
        <div className="font-semibold mb-2">Answers</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {local.answers.map((a, i) => (
            <div key={i} className="grid grid-cols-6 items-center gap-2">
              <Label className="col-span-2">Answer {i + 1}</Label>
              <Input
                className="col-span-3"
                value={a.text}
                onChange={(e) => {
                  const answers = [...local.answers];
                  answers[i] = { ...answers[i], text: e.target.value };
                  setLocal({ ...local, answers });
                }}
              />
              <Input
                type="number"
                value={a.points}
                onChange={(e) => {
                  const answers = [...local.answers];
                  answers[i] = { ...answers[i], points: Number(e.target.value || 0) };
                  setLocal({ ...local, answers });
                }}
              />
            </div>
          ))}
        </div>
        <div className="mt-2 flex gap-2">
          <Button onClick={() => setLocal({ ...local, answers: [...local.answers, { text: "", points: 0 }] })}>Add Answer</Button>
          {local.answers.length > 1 && (
            <Button variant="destructive" onClick={() => setLocal({ ...local, answers: local.answers.slice(0, -1) })}>
              Remove Last
            </Button>
          )}
        </div>
      </div>
      <div className="flex justify-end gap-2">
        <Button onClick={() => onSave({ ...local, answers: local.answers.filter((a) => a.text.trim().length) })}>Save</Button>
      </div>
    </div>
  );
}

function ControlBar({ game, setGame, push }: { game: GameState; setGame: (g: GameState) => void; push?: (g: GameState) => void }) {
  const update = (partial: Partial<GameState>) => {
    const g = { ...game, ...partial, lastUpdated: Date.now() };
    setGame(g);
    push?.(g);
  };
  function toggleTimer() {
    update({ timer: { ...game.timer, running: !game.timer.running } });
  }
  function resetTimer() {
    update({ timer: { ...game.timer, remaining: game.timer.duration, running: false } });
  }
  function incStrikes(delta: number) {
    const next = Math.max(0, Math.min(3, game.strikeCount + delta));
    update({ strikeCount: next, phase: next >= 3 ? "steal" : game.phase });
    if (next >= 3 && game.soundEnabled) play(SOUND_BUZZ);
  }
  function revealAll(v: boolean) {
    const currentQ = game.currentQuestionId ? game.questions[game.currentQuestionId] : undefined;
    if (!currentQ) return;
    const newQ = { ...currentQ, answers: currentQ.answers.map((a) => ({ ...a, revealed: v })) };
    const roundPoints = newQ.answers.reduce((sum, a) => sum + (a.revealed ? a.points : 0), 0) * game.roundMultiplier;
    update({ showAnswers: v, questions: { ...game.questions, [newQ.id]: newQ }, pot: roundPoints });
  }
  function revealIndex(idx: number) {
    const q = game.currentQuestionId ? game.questions[game.currentQuestionId] : undefined;
    if (!q) return;
    const answers = q.answers.map((a, i) => (i === idx ? { ...a, revealed: !a.revealed } : a));
    const revealedPoints = answers.reduce((sum, a) => sum + (a.revealed ? a.points : 0), 0);
    update({ questions: { ...game.questions, [q.id]: { ...q, answers } }, pot: revealedPoints * game.roundMultiplier });
    if (answers[idx].revealed && game.soundEnabled) play(SOUND_DING);
  }
  function awardPot(toTeamId: string) {
    const t = game.teams.map((t) => (t.id === toTeamId ? { ...t, score: t.score + game.pot } : t));
    update({ teams: t });
    if (game.soundEnabled)
      confetti({ origin: { x: 0.5, y: 0.6 }, particleCount: 120, spread: 70 });
  }
  function nextRound() {
    update({ strikeCount: 0, pot: 0, phase: "faceoff", buzzerLocked: false, buzzerWinnerTeamId: undefined, showAnswers: false });
  }

  const currentQ = game.currentQuestionId ? game.questions[game.currentQuestionId] : undefined;

  return (
    <Section title="Live Controls (Admin / Judge)">
      <div className="flex flex-wrap items-center gap-2">
        <Button onClick={toggleTimer}>{game.timer.running ? (<><Pause className="mr-2" size={16} />Pause</>) : (<><Play className="mr-2" size={16} />Start</>)}</Button>
        <Button variant="outline" onClick={resetTimer}>
          <TimerReset className="mr-2" size={16} /> Reset
        </Button>
        <div className="flex items-center gap-2 ml-3">
          <Label>Duration (s)</Label>
          <Input
            type="number"
            className="w-24"
            value={game.timer.duration}
            onChange={(e) =>
              update({
                timer: {
                  ...game.timer,
                  duration: Math.max(5, Number(e.target.value || 0)),
                  remaining: Math.max(5, Number(e.target.value || 0)),
                },
              })
            }
          />
        </div>
        <div className="flex items-center gap-2 ml-3">
          <Label>Strikes</Label>
          <Button variant="outline" size="icon" onClick={() => incStrikes(-1)}>
            <Minus size={16} />
          </Button>
          <div className="w-10 text-center font-bold">{game.strikeCount}</div>
          <Button size="icon" onClick={() => incStrikes(+1)}>
            <Plus size={16} />
          </Button>
        </div>
        <div className="flex items-center gap-3 ml-4">
          <Label>Round</Label>
          <Select value={String(game.roundMultiplier)} onValueChange={(v) => update({ roundMultiplier: Number(v) as 1 | 2 | 3 })}>
            <SelectTrigger className="w-28">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">Single (x1)</SelectItem>
              <SelectItem value="2">Double (x2)</SelectItem>
              <SelectItem value="3">Triple (x3)</SelectItem>
            </SelectContent>
          </Select>
          <div className="text-sm opacity-80">
            Pot: <span className="font-bold">{game.pot}</span>
          </div>
        </div>
        <div className="flex items-center gap-2 ml-3">
          <Label>Reveal All</Label>
          <Switch checked={game.showAnswers} onCheckedChange={revealAll} />
        </div>
        <div className="ml-auto flex items-center gap-3">
          <Label>Sounds</Label>
          <Switch checked={game.soundEnabled} onCheckedChange={(v) => update({ soundEnabled: v })} />
        </div>
      </div>

      <div className="mt-3 grid md:grid-cols-2 gap-3">
        <Card className="p-3">
          <div className="font-semibold mb-2">Current Question</div>
          {currentQ ? (
            <div>
              <div className="uppercase text-xs opacity-70">{currentQ.category || "General"}</div>
              <div className="text-lg font-bold mb-2">{currentQ.prompt}</div>
              <div className="grid grid-cols-2 gap-2">
                {currentQ.answers.map((a, idx) => (
                  <Button key={idx} variant={a.revealed ? "secondary" : "default"} onClick={() => revealIndex(idx)}>
                    {a.revealed ? <EyeOff className="mr-2" size={16} /> : <Eye className="mr-2" size={16} />} {a.text} ({a.points})
                  </Button>
                ))}
              </div>
            </div>
          ) : (
            <div className="opacity-70">Select a question from the Questions list.</div>
          )}
        </Card>
        <Card className="p-3">
          <div className="font-semibold mb-2">Host Notes (visible on Host view)</div>
          <Textarea
            placeholder="Remind host about tie-breaker, pacing, bonus rules, etc."
            value={game.hostNotes || ""}
            onChange={(e) => update({ hostNotes: e.target.value })}
          />
          <div className="mt-3 grid grid-cols-2 gap-2">
            {game.teams.map((t) => (
              <Button key={t.id} variant="outline" onClick={() => awardPot(t.id)}>
                <Trophy className="mr-2" size={16} /> Award Pot to {t.name}
              </Button>
            ))}
            <Button variant="secondary" onClick={nextRound}>
              <Swords className="mr-2" size={16} /> Next Round
            </Button>
          </div>
        </Card>
      </div>
    </Section>
  );
}

function BuzzerPanel({ game, setGame, push }: { game: GameState; setGame: (g: GameState) => void; push?: (g: GameState) => void }) {
  const update = (partial: Partial<GameState>) => {
    const g = { ...game, ...partial, lastUpdated: Date.now() };
    setGame(g);
    push?.(g);
  };
  function buzz(teamId: string) {
    if (game.phase !== "faceoff" || game.buzzerLocked) return;
    update({ buzzerLocked: true, buzzerWinnerTeamId: teamId, turnTeamId: teamId });
    play(SOUND_DING);
  }
  function resetBuzz() {
    update({ buzzerLocked: false, buzzerWinnerTeamId: undefined });
  }
  return (
    <Section title="Face-off Buzzer">
      <div className="grid md:grid-cols-3 gap-3 items-stretch">
        {game.teams.map((t) => (
          <Button
            key={t.id}
            className={`h-20 text-xl ${game.buzzerWinnerTeamId === t.id ? "ring-2 ring-green-600" : ""}`}
            onClick={() => buzz(t.id)}
          >
            <Hand className="mr-2" /> {t.name} Buzz
          </Button>
        ))}
        <Button variant="outline" onClick={resetBuzz} className="h-20">
          Reset Lockout
        </Button>
      </div>
      <div className="mt-2 text-sm opacity-80">
        Tip: Use this on the Admin device. If Firebase is enabled, you can open two Host pages (one per player) and have them tap to buzz.
      </div>
    </Section>
  );
}

function ProjectorBoard({ game }: { game: GameState }) {
  const q = game.currentQuestionId ? game.questions[game.currentQuestionId] : undefined;
  return (
    <div className={game.boardTheme === "dark" ? "bg-black text-white min-h-screen" : "bg-white text-black min-h-screen"}>
      <div className="max-w-6xl mx-auto p-6">
        <div className="flex justify-between items-center mb-4">
          <div className="text-2xl font-extrabold tracking-wide">Survey Showdown</div>
          <TimerLarge timer={game.timer} />
        </div>
        <div className="grid grid-cols-3 gap-4">
          <Card className="col-span-2 p-4">
            <div className="uppercase text-xs opacity-70">{q?.category || "Category"}</div>
            <div className="text-2xl font-bold mb-2">{q?.prompt || "Awaiting question..."}</div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
              {(q?.answers || Array.from({ length: 8 }).map(() => ({ text: "", points: 0, revealed: false }))).map((a, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl p-3 border shadow">
                  <div className="flex items-center justify-between">
                    <div className="text-lg font-semibold">{a.revealed || game.showAnswers ? a.text : `Answer ${i + 1}`}</div>
                    <div className="text-xl font-black">{a.revealed || game.showAnswers ? formatPoints(a.points) : ""}</div>
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="mt-4 flex items-center gap-3">
              <div className="text-lg">Strikes:</div>
              <div className="flex gap-2">
                {[0, 1, 2].map((i) => (
                  <div key={i} className={`w-10 h-10 rounded-full border-2 ${i < game.strikeCount ? "bg-red-600" : "bg-transparent"}`}></div>
                ))}
              </div>
            </div>
            <div className="mt-2 text-sm opacity-80">
              Round: x{game.roundMultiplier} • Pot: <span className="font-bold">{game.pot}</span>
            </div>
          </Card>
          <Card className="p-4">
            <div className="text-lg font-bold mb-2">Scores</div>
            <div className="space-y-2">
              {game.teams.map((t) => (
                <div key={t.id} className={`flex items-center justify-between p-2 rounded-lg border ${game.turnTeamId === t.id ? "bg-green-600/10" : ""}`}>
                  <span className="font-semibold">{t.name}</span>
                  <span className="text-xl font-black">{t.score}</span>
                </div>
              ))}
            </div>
            {game.phase === "faceoff" && game.buzzerWinnerTeamId && (
              <div className="mt-3 text-sm">
                Face-off winner: <span className="font-bold">{game.teams.find((t) => t.id === game.buzzerWinnerTeamId)?.name}</span>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

function TimerLarge({ timer }: { timer: TimerState }) {
  return <div className={`text-3xl font-black ${timer.running && timer.remaining <= 5 ? "animate-pulse" : ""}`}>{timer.remaining}s</div>;
}

function HostView({ game, setGame }: { game: GameState; setGame: (g: GameState) => void }) {
  const update = (partial: Partial<GameState>) => setGame({ ...game, ...partial, lastUpdated: Date.now() });
  const q = game.currentQuestionId ? game.questions[game.currentQuestionId] : undefined;
  const [guess, setGuess] = useState("");
  const fuse = useMemo(() => buildFuse(q?.answers || []), [q?.answers]);
  const suggestion = useMemo(() => {
    if (!guess.trim() || !q) return null;
    const best = fuse.search(normalize(guess))[0];
    return best && best.score! < 0.5 ? best.item : null;
  }, [guess, q, fuse]);

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <Card className="p-4 mb-3">
        <div className="text-sm uppercase opacity-70">Host View</div>
        <div className="text-lg font-bold">{q?.prompt || "Waiting for admin to select a question..."}</div>
        {q?.notes && (
          <Alert className="mt-2">
            <AlertTitle>Notes</AlertTitle>
            <AlertDescription>{q.notes}</AlertDescription>
          </Alert>
        )}
        {game.hostNotes && (
          <Alert className="mt-2" variant="default">
            <AlertTitle>Admin Message</AlertTitle>
            <AlertDescription>{game.hostNotes}</AlertDescription>
          </Alert>
        )}
        <div className="mt-3 text-sm opacity-80">Timer: {game.timer.remaining}s • Strikes: {game.strikeCount} • Round x{game.roundMultiplier}</div>
      </Card>
      {q && (
        <Card className="p-4">
          <div className="text-sm opacity-70 mb-2">Type a team guess to help the judge (auto-suggests a matching answer)</div>
          <div className="flex gap-2 items-center">
            <Input placeholder="Team says…" value={guess} onChange={(e) => setGuess(e.target.value)} />
            {suggestion && (
              <div className="text-xs opacity-80">
                Suggestion: <span className="font-semibold">{suggestion.text}</span> ({suggestion.points})
              </div>
            )}
          </div>
          <div className="grid grid-cols-2 gap-2 mt-3">
            {(q?.answers || []).map((a, i) => (
              <div key={i} className="text-sm p-2 border rounded-lg flex items-center justify-between">
                <span className={`${a.revealed ? "line-through" : ""}`}>{a.text}</span>
                <span className="font-semibold">{a.points}</span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

function ShareLinks({ gameId }: { gameId: string }) {
  const { toast } = useToast();
  const isBrowser = typeof window !== "undefined";
  const publicBase = isBrowser ? getPublicBase() : "";
  const fallbackBase = isBrowser ? window.location.origin : "";
  const base = publicBase || fallbackBase;
  const urls = buildRoleUrls(base, gameId);
  const adminUrl = urls.admin;
  const hostUrl = urls.host;
  const boardUrl = urls.board;

  async function copyUrl(t: string) {
    const ok = await safeCopy(t);
    toast({ title: ok ? "Copied" : "Copy blocked", description: ok ? "Link copied to clipboard." : "Select and copy the URL manually." });
  }
  function openHere(role: "admin" | "host" | "board") {
    if (!isBrowser) return;
    const u = new URL(window.location.href);
    u.searchParams.set("role", role);
    u.searchParams.set("game", gameId);
    window.history.replaceState({}, "", u.toString());
    window.dispatchEvent(new Event("popstate"));
  }
  function openNew(role: "admin" | "host" | "board") {
    if (!isBrowser) return;
    const url = role === "admin" ? adminUrl : role === "host" ? hostUrl : boardUrl;
    const inCanvasPreview = /chat\.openai\.com/.test(window.location.hostname);
    if (inCanvasPreview && !publicBase) {
      copyUrl(url);
      toast({
        title: "New tab blocked in preview",
        description: "Set a Public Base URL in Settings (your deployed domain) or use Open here.",
      });
      return;
    }
    window.open(url, "_blank", "noopener");
  }

  const inCanvasPreview = isBrowser && /chat\.openai\.com/.test(window.location.hostname);

  return (
    <Section title="Share Links">
      {inCanvasPreview && (
        <Alert>
          <AlertTitle>Heads up</AlertTitle>
          <AlertDescription>
            In this preview, new tabs may be blank. For real links, set a <b>Public Base URL</b> in Settings (e.g. your Firebase Hosting domain), then use <b>Copy URL</b> or <b>New tab</b>.
          </AlertDescription>
        </Alert>
      )}
      <div className="grid md:grid-cols-3 gap-3 mt-3">
        {[
          { label: "Admin / Judge", url: adminUrl, role: "admin" as const, icon: Projector },
          { label: "Host Tablet", url: hostUrl, role: "host" as const, icon: MonitorSmartphone },
          { label: "Projector Board", url: boardUrl, role: "board" as const, icon: Projector },
        ].map((x, i) => (
          <Card key={i} className="p-3 space-y-2">
            <div className="text-sm opacity-70 flex items-center gap-2"><LinkIcon size={14} /> {x.label}</div>
            <div className="text-xs break-all bg-muted p-2 rounded">{x.url}</div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => copyUrl(x.url)}>
                <Copy className="mr-2" size={14} /> Copy URL
              </Button>
              <Button size="sm" onClick={() => openHere(x.role)}>Open here</Button>
              <Button size="sm" variant="secondary" onClick={() => openNew(x.role)}>New tab</Button>
            </div>
          </Card>
        ))}
      </div>
      {(!publicBase) && (
        <div className="text-xs opacity-80 mt-3">
          Tip: After you deploy (e.g. <code>https://your-app.web.app</code>), set it in <b>Settings → Public Base URL</b> so these links work across devices.
        </div>
      )}
    </Section>
  );
}

function Settings({ game, setGame, setFirebaseConfig }: { game: GameState; setGame: (g: GameState) => void; setFirebaseConfig: (cfg: any) => void }) {
  const update = (partial: Partial<GameState>) => setGame({ ...game, ...partial, lastUpdated: Date.now() });
  const [cfgText, setCfgText] = useState<string>(() => {
    try {
      return typeof window !== "undefined" ? localStorage.getItem("surveyshowdown_firebase") || "" : "";
    } catch {
      return "";
    }
  });
  const [publicBase, setPublicBaseState] = useState<string>(() => (typeof window !== "undefined" ? getPublicBase() : ""));

  function exportJSON() {
    const blob = new Blob([JSON.stringify(game, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `survey_showdown_${game.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  function importJSON(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const loaded = JSON.parse(String(reader.result));
        setGame({ ...loaded, lastUpdated: Date.now() });
      } catch {
        alert("Invalid JSON");
      }
    };
    reader.readAsText(file);
  }

  return (
    <Section title="Settings">
      <div className="grid md:grid-cols-2 gap-3">
        <div>
          <div className="font-semibold mb-1">Firebase Config (optional for realtime sync)</div>
          <Textarea
            rows={8}
            placeholder='{"apiKey":"...","authDomain":"...","projectId":"..."}'
            value={cfgText}
            onChange={(e) => setCfgText(e.target.value)}
          />
          <div className="mt-2 flex gap-2">
            <Button
              onClick={() => {
                try {
                  const obj = JSON.parse(cfgText);
                  setFirebaseConfig(obj);
                } catch {
                  alert("Invalid JSON");
                }
              }}
            >
              Save
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setFirebaseConfig(null);
                setCfgText("");
              }}
            >
              Clear
            </Button>
          </div>
          <div className="text-xs opacity-70 mt-2">
            Paste your Firebase web app config JSON to enable cross-device syncing (Firestore + Anonymous Auth).
          </div>
        </div>
        <div>
          <div className="font-semibold mb-1">Game Options & Backup</div>
          <div className="grid grid-cols-2 gap-2 items-center">
            <Label>Game ID</Label>
            <Input value={game.id} onChange={(e) => update({ id: e.target.value })} />
            <Label>Board Theme</Label>
            <Select value={game.boardTheme} onValueChange={(v) => update({ boardTheme: v as any })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dark">Dark</SelectItem>
                <SelectItem value="light">Light</SelectItem>
              </SelectContent>
            </Select>
            <Label>Export / Import</Label>
            <div className="flex gap-2">
              <Button variant="outline" onClick={exportJSON}>
                Export JSON
              </Button>
              <Input type="file" accept="application/json" onChange={(e) => e.target.files && importJSON(e.target.files[0])} />
            </div>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2 items-center">
            <Label>Public Base URL</Label>
            <Input
              placeholder="https://your-app.web.app"
              value={publicBase}
              onChange={(e) => {
                setPublicBaseState(e.target.value);
              }}
              onBlur={(e) => setPublicBase(e.target.value)}
            />
            <div className="col-span-2 text-xs opacity-70">
              This is the domain where you will host Survey Showdown (e.g., Firebase Hosting). Share links will use this base.
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}

function TopNav({ role, onRoleChange, onOpenSetup, connected }: { role: string; onRoleChange: (r: string) => void; onOpenSetup: () => void; connected: boolean }) {
  return (
    <div className="sticky top-0 z-50 bg-background/80 backdrop-blur border-b">
      <div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-3">
        <div className="text-xl font-black tracking-wide">Survey Showdown</div>
        <div className="ml-auto flex items-center gap-2">
          <span className={`text-xs px-2 py-1 rounded-full ${connected ? "bg-green-200 text-green-900" : "bg-amber-200 text-amber-900"}`}>
            {connected ? "Connected" : "Local"}
          </span>
          <Button variant="outline" onClick={onOpenSetup}>
            <Cog className="mr-2" size={16} /> Setup
          </Button>
          <Select value={role} onValueChange={onRoleChange}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="admin">Admin / Judge</SelectItem>
              <SelectItem value="host">Host</SelectItem>
              <SelectItem value="board">Projector Board</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}

function SetupWizard({ open, setOpen, setFirebaseConfig }: { open: boolean; setOpen: (v: boolean) => void; setFirebaseConfig: (cfg: any) => void }) {
  const [cfgText, setCfgText] = useState<string>(() => {
    try {
      return typeof window !== "undefined" ? localStorage.getItem("surveyshowdown_firebase") || "" : "";
    } catch {
      return "";
    }
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Connect to Firebase</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <p className="text-sm opacity-80">
            Paste your Firebase Web SDK config JSON here. You can get it from Firebase Console → Project settings → General → Your apps → Web → Config.
          </p>
          <Textarea
            rows={10}
            placeholder='{"apiKey":"...","authDomain":"...","projectId":"...","appId":"..."}'
            value={cfgText}
            onChange={(e) => setCfgText(e.target.value)}
          />
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Close
            </Button>
            <Button
              onClick={() => {
                try {
                  const obj = JSON.parse(cfgText);
                  setFirebaseConfig(obj);
                  localStorage.setItem("surveyshowdown_firebase", JSON.stringify(obj));
                  setOpen(false);
                } catch {
                  alert("Invalid JSON");
                }
              }}
            >
              Save
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// -------------------------
// Dev self-tests (lightweight, non-blocking)
// -------------------------
function runDevSelfTests() {
  try {
    // Test 1: CSV parsing basic
    const csv = Papa.unparse({ fields: ["category", "question", "answer1", "score1", "notes"], data: [["Cat", "Q?", "Ans", "5", "n"]] });
    const parsed = parseCSVToQuestions(csv);
    console.assert(parsed.length === 1 && parsed[0].answers[0].points === 5, "CSV parse failed");

    // Test 2: Template contains headers
    const tmpl = questionsToCSVTemplate();
    console.assert(tmpl.includes("category,question,answer1,score1"), "Template headers missing");

    // Test 3: useInterval exists
    console.assert(typeof useInterval === "function", "useInterval missing");

    // Test 4: Normalize removes punctuation and squashes spaces
    console.assert(normalize("Pepp-er!! oni  ") === "pepp er oni", "normalize failed");

    // Test 5: Pot calculation with multiplier
    const q: Question = { id: "q1", prompt: "p", answers: [{ text: "a", points: 10, revealed: true }, { text: "b", points: 5, revealed: true }] } as any;
    const revealedPoints = q.answers.reduce((s, a) => s + (a as any).points, 0);
    console.assert(revealedPoints * 2 === 30, "pot math failed");

    // Test 6: Cloud sync gracefully no-ops without Firestore
    const tmp = useCloudSync(null as any, () => {});
    console.assert(typeof tmp.push === "function" && (tmp.connected === false || tmp.connected === true), "cloud hook shape ok");

    // Test 7: safeCopy exists and returns a Promise
    const p = safeCopy("test");
    console.assert(p && typeof (p as any).then === "function", "safeCopy should be async Promise");

    // Test 8: buildRoleUrls creates role-specific links
    const links = buildRoleUrls("https://example.com/app", "G123");
    console.assert(links.admin === "https://example.com/app?role=admin&game=G123", "admin link bad");
    console.assert(links.host === "https://example.com/app?role=host&game=G123", "host link bad");
    console.assert(links.board === "https://example.com/app?role=board&game=G123", "board link bad");

    // Test 8b: buildRoleUrls strips trailing /index.html
    const links2 = buildRoleUrls("https://example.com/index.html", "G1");
    console.assert(links2.host === "https://example.com?role=host&game=G1", "index.html stripping failed");

    // Test 9: Public base storage helpers round-trip
    setPublicBase("");
    console.assert(getPublicBase() === "" || typeof window === "undefined", "public base clear failed (ignored in SSR)");
  } catch (e) {
    console.warn("Self-tests warning:", e);
  }
}
if (typeof window !== "undefined") runDevSelfTests();

// -------------------------
// App
// -------------------------

export default function App() {
  const isBrowser = typeof window !== "undefined";
  const url = isBrowser ? new URL(window.location.href) : new URL("https://local.invalid/");
  const initialRole = ((isBrowser ? url.searchParams.get("role") : "admin") || "admin") as "admin" | "host" | "board";
  const initialGame = (isBrowser ? url.searchParams.get("game") : null) || uuidv4().slice(0, 8);

  const [role, setRole] = useState<"admin" | "host" | "board">(initialRole);
  const [wizardOpen, setWizardOpen] = useState<boolean>(() => {
    try {
      return isBrowser ? !localStorage.getItem("surveyshowdown_firebase") : true;
    } catch {
      return true;
    }
  });
  const [game, setGame] = useState<GameState>(() => {
    try {
      if (!isBrowser) return blankGame(initialGame);
      const cached = localStorage.getItem(`surveyshowdown_game_${initialGame}`);
      return cached ? JSON.parse(cached) : blankGame(initialGame);
    } catch {
      return blankGame(initialGame);
    }
  });

  const { connected, setFirebaseConfig, push, error } = useCloudSync(game, (g) => setGame(g));

  useEffect(() => {
    try {
      if (typeof window !== "undefined") localStorage.setItem(`surveyshowdown_game_${game.id}`, JSON.stringify(game));
    } catch {}
  }, [game]);

  // Respond to URL changes from ShareLinks → Open here
  useEffect(() => {
    if (typeof window === "undefined") return;
    const onPop = () => {
      try {
        const u = new URL(window.location.href);
        const r = ((u.searchParams.get("role") || "admin") as "admin" | "host" | "board");
        const g = u.searchParams.get("game") || game.id;
        if (r !== role) setRole(r);
        if (g !== game.id) {
          let loaded: GameState | null = null;
          try {
            const cached = localStorage.getItem(`surveyshowdown_game_${g}`);
            loaded = cached ? JSON.parse(cached) : null;
          } catch {}
          setGame(loaded || blankGame(g));
        }
      } catch {}
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, [role, game.id]);

  // Timer tick (admin pushes updates if connected)
  useInterval(() => {
    if (!game.timer.running) return;
    if (game.timer.remaining <= 0) return;
    const next = { ...game, timer: { ...game.timer, remaining: game.timer.remaining - 1 }, lastUpdated: Date.now() };
    setGame(next);
    if (connected) push(next);
  }, 1000);

  const adminPanels = (
    <div className="max-w-6xl mx-auto p-4 space-y-4">
      {error === "firestore_unavailable" && (
        <Alert>
          <AlertTitle>Running in Local Mode</AlertTitle>
          <AlertDescription>Firestore isn’t available in this preview/sandbox. The game will still work locally; deploy to Hosting for realtime multi-device sync.</AlertDescription>
        </Alert>
      )}
      <Alert>
        <AlertTitle>Welcome to Survey Showdown</AlertTitle>
        <AlertDescription>
          Share links for Host (tablet) and Projector (board). Upload CSV using the provided template. Control timer, round multiplier, buzzer, strikes, reveals, and pot. Award the pot when a team wins.
        </AlertDescription>
      </Alert>
      <ShareLinks gameId={game.id} />
      <TeamEditor game={game} setGame={setGame} push={connected ? push : undefined} />
      <QuestionsManager game={game} setGame={setGame} push={connected ? push : undefined} />
      <BuzzerPanel game={game} setGame={setGame} push={connected ? push : undefined} />
      <ControlBar game={game} setGame={setGame} push={connected ? push : undefined} />
      <Settings game={game} setGame={setGame} setFirebaseConfig={setFirebaseConfig} />
    </div>
  );

  const hostPanel = <div><HostView game={game} setGame={setGame} /></div>;
  const boardPanel = <ProjectorBoard game={game} />;

  return (
    <TooltipProvider>
      <TopNav role={role} onRoleChange={setRole as any} onOpenSetup={() => setWizardOpen(true)} connected={connected} />
      {role === "admin" && adminPanels}
      {role === "host" && hostPanel}
      {role === "board" && boardPanel}
      <SetupWizard open={wizardOpen} setOpen={setWizardOpen} setFirebaseConfig={setFirebaseConfig} />
    </TooltipProvider>
  );
}
