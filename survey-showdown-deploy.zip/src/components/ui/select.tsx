
import * as React from "react";

type SelectRootProps = {
  value?: string;
  onValueChange?: (v: string) => void;
  children: React.ReactNode;
};

function collectItems(node: React.ReactNode, acc: Array<{value: string; label: React.ReactNode}>, classHint: {triggerClass?: string}) {
  React.Children.forEach(node as any, (child: any) => {
    if (!child) return;
    if (child.type && child.type.displayName === "SelectItem") {
      acc.push({ value: child.props.value, label: child.props.children });
    } else if (child.props && child.props.children) {
      if (child.props["data-select-trigger"] && child.props.className && !classHint.triggerClass) {
        classHint.triggerClass = child.props.className;
      }
      collectItems(child.props.children, acc, classHint);
    }
  });
}

export function Select({ value, onValueChange, children }: SelectRootProps) {
  const items: Array<{value: string; label: React.ReactNode}> = [];
  const classHint: {triggerClass?: string} = {};
  collectItems(children, items, classHint);
  return (
    <select
      className={`h-10 rounded-md border border-white/10 bg-white/10 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${classHint.triggerClass || ""}`}
      value={value}
      onChange={(e) => onValueChange?.(e.target.value)}
    >
      {items.map((it) => (
        <option key={it.value} value={it.value}>
          {typeof it.label === "string" ? it.label : (React.isValidElement(it.label) ? (it.label as any).props?.children : "Option")}
        </option>
      ))}
    </select>
  );
}

export function SelectTrigger({ className = "", children }: any) {
  return <span data-select-trigger className={className} style={{ display: "none" }}>{children}</span>;
}
export function SelectContent({ children }: any) { return <>{children}</>; }
export function SelectItem({ children }: any) { return <>{children}</>; }
export function SelectValue() { return null; }

SelectTrigger.displayName = "SelectTrigger";
SelectContent.displayName = "SelectContent";
SelectItem.displayName = "SelectItem";
SelectValue.displayName = "SelectValue";
