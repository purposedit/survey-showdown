
import * as React from "react";

type Ctx = { open: boolean; setOpen: (v: boolean) => void };
const DialogCtx = React.createContext<Ctx | null>(null);

export function Dialog({ open: controlledOpen, onOpenChange, children }: any) {
  const [uncontrolled, setUncontrolled] = React.useState(false);
  const open = controlledOpen ?? uncontrolled;
  const setOpen = (v: boolean) => {
    if (controlledOpen === undefined) setUncontrolled(v);
    onOpenChange?.(v);
  };
  return <DialogCtx.Provider value={{ open, setOpen }}>{children}</DialogCtx.Provider>;
}

export function DialogTrigger({ asChild = false, children }: any) {
  const ctx = React.useContext(DialogCtx)!;
  const child = React.Children.only(children) as any;
  const props = {
    onClick: (...args: any[]) => {
      ctx.setOpen(true);
      if (child.props?.onClick) child.props.onClick(...args);
    },
  };
  return asChild && React.isValidElement(child) ? React.cloneElement(child, props) : <button {...props}>{children}</button>;
}

export function DialogContent({ className = "", children }: any) {
  const ctx = React.useContext(DialogCtx)!;
  if (!ctx.open) return null;
  return <div className={`rounded-2xl border border-white/10 bg-white/10 p-4 ${className}`}>{children}</div>;
}
export function DialogHeader({ children }: any) { return <div className="mb-2">{children}</div>; }
export function DialogTitle({ children }: any) { return <h3 className="text-lg font-semibold">{children}</h3>; }
