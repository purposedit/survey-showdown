
import * as React from "react";

export function Alert({ className = "", children }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={`rounded-lg border border-yellow-400/40 bg-yellow-500/10 p-3 ${className}`}>{children}</div>;
}
export function AlertTitle({ children }: any) { return <div className="font-semibold mb-1">{children}</div>; }
export function AlertDescription({ children }: any) { return <div className="text-sm opacity-80">{children}</div>; }
