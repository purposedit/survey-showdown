
import * as React from "react";

type Props = { checked?: boolean; onCheckedChange?: (v: boolean) => void };

export function Switch({ checked = false, onCheckedChange }: Props) {
  return (
    <button
      onClick={() => onCheckedChange?.(!checked)}
      className={`h-6 w-11 rounded-full transition-colors ${checked ? "bg-green-500" : "bg-gray-500"} relative`}
      aria-pressed={checked}
      type="button"
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${checked ? "translate-x-6" : "translate-x-0.5"}`}
      />
    </button>
  );
}
