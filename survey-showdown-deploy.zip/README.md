# Survey Showdown (Vite + React + Tailwind)

This is a ready-to-deploy build of Survey Showdown.

## Optional local run
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Firebase Hosting
1. `firebase init hosting` (public dir: `dist`, SPA: yes)
2. `npm run build`
3. `firebase deploy --only hosting`

Then open your `https://YOUR-PROJECT.web.app` URL and set **Admin → Settings → Public Base URL** to that domain.